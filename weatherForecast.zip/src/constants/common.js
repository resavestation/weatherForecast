export const APIPath = "https://www.metaweather.com/";
