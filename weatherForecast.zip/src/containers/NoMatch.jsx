import React from "react";

const NoMatch = () => {
  return (
    <main className="main main-no-content">
      <h1>ಥ_ಥ Page Not Found</h1>
    </main>
  );
};

export default NoMatch;
